﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;

public partial class index : System.Web.UI.Page
{
    public class User
    {
        private Guid _userID;
        public Guid UserID
        {
            get { return _userID; }
            set { _userID = value; }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _phone;
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }


        private string _email;
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        private bool _allowPost;
        public bool AllowPost
        {
            get { return _allowPost; }
            set { _allowPost = value; }
        }


        private string _postAddress;
        public string PostAddress
        {
            get { return _postAddress; }
            set { _postAddress = value; }
        }

        private string _postCode;
        public string PostCode
        {
            get { return _postCode; }
            set { _postCode = value; }
        }

        private string _moreInfo;
        public string MoreInfo
        {
            get { return _moreInfo; }
            set { _moreInfo = value; }
        }

        private bool _isSaved;
        public bool IsSaved
        {
            get { return _isSaved; }
            set { _isSaved = value; }
        }

        private DateTime _updateDate;
        public DateTime UpdateDate
        {
            get { return _updateDate; }
            set { _updateDate = value; }
        }
    }
    protected static readonly string DBXMLFile = HttpRuntime.AppDomainAppPath + "\\temp\\campus\\DB.xml";

    protected List<User> LoadXMLDB()
    {
        XmlDocument document = new XmlDocument();
        document.Load(DBXMLFile);

        List<User> result = new List<User>(48);
        XmlNodeList nodeList = document.SelectNodes("/Users/User");

        foreach (XmlNode node in nodeList)
        {
            User user = new User();
            user.UserID = new Guid(node.Attributes["id"].Value);
            user.Name = node.Attributes["name"].Value;
            user.Phone = node.Attributes["phone"].Value;
            user.Email = node.Attributes["email"].Value;
            user.AllowPost = bool.Parse(node.Attributes["allowPost"].Value);
            user.PostAddress = node.Attributes["postAddress"].Value;
            user.PostCode = node.Attributes["postCode"].Value;
            user.MoreInfo = node.Attributes["moreInfo"].Value;
            user.IsSaved = bool.Parse(node.Attributes["isSaved"].Value);
            user.UpdateDate = DateTime.Parse(node.Attributes["updateDate"].Value);
            result.Add(user);
        }

        return result;
    }

    protected string SerializeToJson(List<User> list)
    {
        StringBuilder builder = new StringBuilder();
        for(int i=0; i<list.Count; i++)
        {
            User user = list[i];

            builder.Append("{");
            builder.AppendFormat("'userID':'{0}', 'name':'{1}', phone:'{2}', email:'{3}', allowPost:{4}, postAddress:'{5}', postCode:'{6}', moreInfo:'{7}', isSaved:{8}",
                user.UserID,
                FormatJsText(user.Name),
                FormatJsText(user.Phone),
                FormatJsText(user.Email), 
                user.AllowPost.ToString().ToLower(),
                FormatJsText(user.PostAddress),
                FormatJsText(user.PostCode),
                FormatJsText(user.MoreInfo), 
                user.IsSaved.ToString().ToLower());
            builder.Append("}");

            if(i<list.Count-1)
                builder.Append(",");
        }

        return "[" + builder.ToString() + "]";
    }

    private string FormatJsText(string text)
    {
        if (string.IsNullOrEmpty(text))
            return text;
        return text.Replace("'", "\\'").Replace("\r\n", "\\r\\n").Replace("\n", "\\n");
    }

    private List<User> SaveXMLDB(User targetUser)
    {
        XmlDocument document = new XmlDocument();
        document.Load(DBXMLFile);

        List<User> result = new List<User>(48);
        XmlNodeList nodeList = document.SelectNodes("/Users/User");

        foreach (XmlNode node in nodeList)
        {
            User user = new User();
            user.UserID = new Guid(node.Attributes["id"].Value);
            user.Phone = node.Attributes["phone"].Value;
            user.Email = node.Attributes["email"].Value;
            user.AllowPost = bool.Parse(node.Attributes["allowPost"].Value);
            user.PostAddress = node.Attributes["postAddress"].Value;
            user.PostCode = node.Attributes["postCode"].Value;
            user.MoreInfo = node.Attributes["moreInfo"].Value;
            user.IsSaved = bool.Parse(node.Attributes["isSaved"].Value);
            user.UpdateDate = DateTime.Parse(node.Attributes["updateDate"].Value);
            result.Add(user);

            if (targetUser.UserID == user.UserID)
            {
                node.Attributes["phone"].Value = targetUser.Phone;
                node.Attributes["email"].Value = targetUser.Email;
                node.Attributes["allowPost"].Value = targetUser.AllowPost.ToString().ToLower();
                node.Attributes["postAddress"].Value = targetUser.PostAddress;
                node.Attributes["postCode"].Value = targetUser.PostCode;
                node.Attributes["moreInfo"].Value = targetUser.MoreInfo;
                node.Attributes["isSaved"].Value = "true";
                node.Attributes["updateDate"].Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            }
        }

        document.Save(DBXMLFile);
        return result;
    }

    protected override void OnPreLoad(System.EventArgs e)
    {
        base.OnPreLoad(e);
        if (this.Request.QueryString["update"] == "true")
        {
            User user = new User();
            user.UserID = new Guid(this.Request.QueryString["userID"]);
            user.Phone = this.Request["phone"];
            user.Email = this.Request["email"];
            user.AllowPost = this.Request["allowPost"] == "on";
            user.PostAddress = this.Request["postAddress"];
            user.PostCode = this.Request["PostCode"];
            user.MoreInfo = this.Request["MoreInfo"];

            Response.ContentType = "application/json";
            Response.Write(SerializeToJson(SaveXMLDB(user)));
            Response.End();
        }
    }

}